PAYCHEX QUICKBOOKS IMPORTER — PUBLIC LEGAL PAGES

BEFORE PUBLISHING:
1. Replace [LEGAL NAME OF APPLICATION OWNER OR BUSINESS], [PUBLIC SUPPORT EMAIL], [PUBLIC PRIVACY EMAIL], and any applicable mailing location.
2. Verify privacy text accurately reflects the production app, particularly token encryption, file storage, logs, retention, and deletion. Have counsel review if appropriate.
3. Upload ONLY index.html, terms.html, and privacy.html to a PUBLIC GitHub repository called paychex-importer-legal. Do not upload .env, app code, token databases, or payroll files.
4. GitHub repository Settings > Pages > Deploy from a branch > main > /(root) > Save.
5. Once live, fill in Intuit URLs:
https://YOUR-USERNAME.github.io/paychex-importer-legal/terms.html
https://YOUR-USERNAME.github.io/paychex-importer-legal/privacy.html
These are placeholders until the site is published.
