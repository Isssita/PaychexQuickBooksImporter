@echo off
cd /d "%~dp0"
if not exist ".env" (
 echo ERROR: Primero ejecuta 01_INSTALL_WINDOWS.bat y configura .env
 pause
 exit /b 1
)
echo Iniciando Paychex QuickBooks Sandbox en http://localhost:8765
start "" "http://localhost:8765"
py app.py
if errorlevel 1 (
 echo ERROR AL INICIAR. Revisa los mensajes anteriores.
 pause
)
