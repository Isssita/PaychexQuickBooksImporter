import os
from pathlib import Path
import unittest
from tempfile import TemporaryDirectory
from unittest.mock import patch

from paychex_parser_legacy import records

class ParserTests(unittest.TestCase):
    def test_csv(self):
        with TemporaryDirectory() as d:
            path = Path(d) / 'sample.csv'
            path.write_text('Check Number,Payee Name,Check Date,Payment Amount\n1001,Example Employee,09/04/2026,1250.55\n', encoding='utf-8')
            rows = records(path)
            self.assertEqual(rows[0]['date'], '2026-09-04')
            self.assertEqual(str(rows[0]['amount']), '1250.55')
    def test_duplicate_in_upload(self):
        with TemporaryDirectory() as d:
            path = Path(d) / 'sample.csv'
            path.write_text('Check Number,Payee Name,Check Date,Payment Amount\n1001,Employee,09/04/2026,10\n1001,Employee,09/04/2026,10\n')
            with self.assertRaises(ValueError):
                records(path)

if __name__ == '__main__': unittest.main()
