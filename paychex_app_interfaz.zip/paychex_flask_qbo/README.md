# Paychex → QuickBooks Online | Interfaz web local

**Entorno Sandbox exclusivamente. No publicar en Production.**

Esta es la versión con interfaz gráfica del importador que ya probaste desde consola. La carpeta anterior `paychex_qbo_importer` NO se modifica. La nueva aplicación requiere su propia autorización OAuth y archivo `.env`, pero utiliza la misma cuenta Intuit Developer Sandbox y las mismas cuentas contables si autorizas la misma empresa.

## Instalación sencilla en Windows

1. Extrae completamente `paychex_app_interfaz.zip` en una carpeta independiente, por ejemplo `Descargas\paychex_flask_qbo`.
2. Abre la carpeta y haz doble clic en `01_INSTALL_WINDOWS.bat` para instalar las dependencias y generar una plantilla `.env`. No copies el archivo `config.json` de la primera versión.
3. En la carpeta abre una terminal y ejecuta `py generate_keys.py`. Copia los resultados PRIVADAMENTE a `.env` en `FLASK_SECRET_KEY` y `TOKEN_ENCRYPTION_KEY`.
4. Abre `.env` con Bloc de notas y configura `INTUIT_CLIENT_ID`, `INTUIT_CLIENT_SECRET` de **Development**, `INTUIT_REDIRECT_URI=http://localhost:8765/oauth/callback`, `QBO_ENV=sandbox`. Como anteriormente se compartió un Client Secret en un chat, rótalo en Intuit antes de usarlo. No compartas ni subas `.env`.
5. En Intuit Developer → App → Development → Redirect URIs, agrega exactamente `http://localhost:8765/oauth/callback`. Es distinto al callback de consola `http://localhost:8765/callback`. Intuit debe aceptar la URI registrada.
6. Haz doble clic en `02_ABRIR_APP.bat`. Si el navegador carga antes de que Flask se inicie, actualiza la pestaña. La URL es `http://localhost:8765`.
7. Pulsa `Connect QuickBooks Sandbox` para autorizar la empresa de prueba. Si aparece una sesión previa, elige la Sandbox correcta.
8. Elige el archivo de Paychex y `Preview checks`. Puedes verificar totales, empleados, duplicados y cuentas sin publicar nada.
9. Solo cuando todas las filas aparezcan listas y sean datos de **prueba**, escribe el código de confirmación que muestra la pantalla y publica. Confirma el registro del cheque en QuickBooks Sandbox.

## Características

- Lee el Excel original de Paychex o CSV con encabezados compatibles.
- Crea QuickBooks `Purchase` con `PaymentType: Check`, banco `Payroll (CEN 2701)` y categoría `1050 Clearing Accrued Payroll`.
- Busca empleados activos por coincidencia exacta del nombre; no crea empleados.
- Detecta duplicados en archivo, QuickBooks Sandbox y registro local. Bloquea completamente una carga con filas ambiguas o duplicadas.
- Autorización OAuth2, `state` y tokens cifrados en SQLite con renovación automática.
- Vista previa, confirmación explícita y revalidación de duplicados antes de publicar.
- Ejecuta solo en localhost, con protección CSRF. No lo expongas a Internet ni a tu red local.
- Los cheques contabilizados aquí **no ejecutan transferencias bancarias** ni se concilian automáticamente con el feed.

## Problemas frecuentes

- `Could not connect`: ejecuta `02_ABRIR_APP.bat`, espera que abra el servidor, y vuelve a cargar el navegador.
- `Redirect URI mismatch`: la URI de `.env` y de Development en Intuit deben coincidir exactamente.
- `No exact active Employee match`: los empleados de tu QuickBooks **real** no están automáticamente en Sandbox. Para probar, crea uno de prueba o usa un reporte de ejemplo. No cambies a producción para resolverlo.
- `Accounts not matched exactly`: confirma nombres y número de cuenta en el catálogo de Sandbox.
- Si una solicitud POST falla o expira, revisa el registro de QuickBooks antes de intentar nuevamente. El programa bloquea reintentos inciertos para evitar duplicados.
- Para salir de la app, cierra la ventana negra del servidor o presiona Ctrl+C.

## Documentación de Intuit

- OAuth2: https://developer.intuit.com/app/developer/qbo/docs/develop/authentication-and-authorization/oauth-2.0
- Purchase Check: https://developer.intuit.com/app/developer/qbo/docs/api/accounting/all-entities/purchase
- Employee: https://developer.intuit.com/app/developer/qbo/docs/api/accounting/all-entities/employee
- Account: https://developer.intuit.com/app/developer/qbo/docs/api/accounting/all-entities/account

No incluyas `.env`, `local_state.db` ni credenciales en archivos ZIP, repositorios o mensajes.
