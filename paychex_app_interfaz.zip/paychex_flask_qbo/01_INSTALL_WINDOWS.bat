@echo off
cd /d "%~dp0"
echo === Paychex QuickBooks: instalar dependencias ===
py -m pip install -r requirements.txt
if errorlevel 1 (
 echo ERROR: No se pudieron instalar las dependencias.
 pause
 exit /b 1
)
echo.
if not exist ".env" (
 copy ".env.example" ".env" >nul
 echo Se creo .env. Se abrira para configurarlo.
 notepad ".env"
) else (
 echo Ya existe .env; NO se sobrescribio.
)
echo.
echo Para generar las claves de seguridad ejecuta: py generate_keys.py
pause
