import secrets
from cryptography.fernet import Fernet
print('FLASK_SECRET_KEY=' + secrets.token_urlsafe(48))
print('TOKEN_ENCRYPTION_KEY=' + Fernet.generate_key().decode())
