#!/usr/bin/env python3
"""Local, review-first Paychex check importer for QuickBooks Online."""
import argparse, base64, csv, datetime as dt, decimal, hashlib, http.server, json, os, pathlib, secrets, sys, threading, time, unicodedata, urllib.parse, webbrowser, xml.etree.ElementTree as ET, zipfile
import requests

ROOT=pathlib.Path(__file__).resolve().parent
CONFIG=ROOT/'config.json'; TOKEN=ROOT/'tokens.json'; LOG=ROOT/'posting_log.jsonl'
API={'sandbox':'https://sandbox-quickbooks.api.intuit.com','production':'https://quickbooks.api.intuit.com'}
AUTH='https://appcenter.intuit.com/connect/oauth2'; TOKEN_URL='https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer'
N={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships','p':'http://schemas.openxmlformats.org/package/2006/relationships'}
D=decimal.Decimal

def save_private(path,data):
    path.write_text(json.dumps(data,indent=2),encoding='utf-8')
    try: os.chmod(path,0o600)
    except OSError: pass

def cfg():
    if not CONFIG.exists(): sys.exit('Create config.json from config.example.json first.')
    x=json.loads(CONFIG.read_text(encoding='utf-8'))
    if x.get('environment') not in API: sys.exit('Invalid environment in config.json')
    for k in ('client_id','client_secret','redirect_uri'):
        if not x.get(k) or str(x[k]).startswith('REPLACE'):sys.exit('Set '+k+' in config.json')
    return x

def qnorm(x):
    x=unicodedata.normalize('NFKD',str(x or ''))
    return ' '.join(''.join(c for c in x if not unicodedata.combining(c)).casefold().split())

def colnum(ref):
    n=0
    for c in ''.join(c for c in ref if c.isalpha()):n=n*26+ord(c.upper())-64
    return n-1

def read_xlsx(file):
    with zipfile.ZipFile(file) as z:
        ss=[]
        if 'xl/sharedStrings.xml' in z.namelist():
            r=ET.fromstring(z.read('xl/sharedStrings.xml'))
            ss=[''.join(n.text or '' for n in e.findall('.//s:t',N)) for e in r]
        wb=ET.fromstring(z.read('xl/workbook.xml')); rel=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        relations={e.attrib['Id']:e.attrib['Target'] for e in rel}
        sheet=wb.find('s:sheets/s:sheet',N)
        target=relations[sheet.attrib['{%s}id'%N['r']]].lstrip('/')
        if not target.startswith('xl/'): target='xl/'+target
        sh=ET.fromstring(z.read(target)); rows=[]
        for r in sh.findall('.//s:sheetData/s:row',N):
            d={}
            for c in r.findall('s:c',N):
                val=c.find('s:v',N); inline=c.find('s:is',N)
                v=(val.text or '') if val is not None else ''.join(x.text or '' for x in inline.findall('.//s:t',N)) if inline is not None else ''
                if c.get('t')=='s' and v:v=ss[int(v)]
                if v:d[colnum(c.get('r'))]=v
            if d: rows.append(d)
        return rows

def records(filename):
    file=pathlib.Path(filename)
    if file.suffix.lower()=='.xlsx':r=read_xlsx(file)
    elif file.suffix.lower()=='.csv':
        with file.open(encoding='utf-8-sig',newline='') as f:r=[{i:v for i,v in enumerate(line)} for line in csv.reader(f)]
    else:sys.exit('Use .xlsx or .csv')
    aliases=[('check number','check number'),('payee name','payee name'),('payee (paychex)','payee name'),('check date','check date'),('payment amount','amount'),('net amount','amount')]
    a=dict(aliases); h=next((i for i,row in enumerate(r) if 'check number' in {qnorm(v) for v in row.values()} and any(qnorm(v) in ('payment amount','net amount') for v in row.values())),None)
    if h is None:sys.exit('Cannot find Paychex check header row')
    cols={a[qnorm(v)]:j for j,v in r[h].items() if qnorm(v) in a}
    if set(cols)!= {'check number','payee name','check date','amount'}:sys.exit('Missing required columns: '+str(cols))
    seen=set(); out=[]
    for row in r[h+1:]:
        num=str(row.get(cols['check number'],'')).strip();name=str(row.get(cols['payee name'],'')).strip()
        if not num or not name:continue
        v=str(row.get(cols['check date'],'')).strip()
        if v.isdigit():date=(dt.datetime(1899,12,30)+dt.timedelta(days=int(v))).date().isoformat()
        else:
            try:date=dt.date.fromisoformat(v[:10]).isoformat()
            except ValueError:
                try:date=dt.datetime.strptime(v,'%m/%d/%Y').date().isoformat()
                except ValueError:raise ValueError('Invalid date: '+v)
        try:amt=D(str(row.get(cols['amount'],'')).replace(',','')).quantize(D('.01'))
        except decimal.InvalidOperation:raise ValueError('Invalid amount for '+num)
        if amt<=0:raise ValueError('Non-positive check '+num)
        key=(date,num)
        if key in seen:raise ValueError('Duplicate Paychex date/check number: '+str(key))
        seen.add(key)
        out.append({'number':num,'name':name,'date':date,'amount':amt,'key':'PAYCHEX-'+date+'-'+num})
    if not out:sys.exit('No valid checks found')
    return out

def oauth_request(c,grant,info):
    b=base64.b64encode((c['client_id']+':'+c['client_secret']).encode()).decode()
    resp=requests.post(TOKEN_URL,headers={'Authorization':'Basic '+b,'Accept':'application/json'},data={'grant_type':grant,**info},timeout=30)
    resp.raise_for_status();return resp.json()

def connect(c):
    port=urllib.parse.urlparse(c['redirect_uri']).port
    if urllib.parse.urlparse(c['redirect_uri']).hostname not in ('localhost','127.0.0.1') or not port:sys.exit('redirect_uri must be http://localhost:PORT/callback')
    state=secrets.token_urlsafe(24);result={}
    class Handler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            q=urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            result.update({k:v[0] for k,v in q.items()})
            msg='Authorization received. Return to the terminal.'
            self.send_response(200);self.send_header('Content-Type','text/plain');self.end_headers();self.wfile.write(msg.encode())
        def log_message(self,*args):pass
    server=http.server.HTTPServer(('127.0.0.1',port),Handler);server.timeout=180
    params={'client_id':c['client_id'],'response_type':'code','scope':'com.intuit.quickbooks.accounting','redirect_uri':c['redirect_uri'],'state':state}
    url=AUTH+'?'+urllib.parse.urlencode(params)
    print('Authorize your company in browser. If browser does not open, visit:\n'+url)
    webbrowser.open(url);server.handle_request();server.server_close()
    if result.get('state')!=state or not result.get('code'):sys.exit('OAuth failed: invalid state, missing code, or timeout')
    t=oauth_request(c,'authorization_code',{'code':result['code'],'redirect_uri':c['redirect_uri']})
    t['realm_id']=result['realmId'];t['obtained_at']=time.time();save_private(TOKEN,t)
    print('Connected QuickBooks company '+t['realm_id']+' ('+c['environment']+').')

def token(c):
    if not TOKEN.exists():sys.exit('Run `python paychex_importer.py connect` first')
    t=json.loads(TOKEN.read_text())
    if time.time()-t.get('obtained_at',0)>3300:
        n=oauth_request(c,'refresh_token',{'refresh_token':t['refresh_token']})
        t.update(n);t['obtained_at']=time.time();save_private(TOKEN,t)
    return t

def api(c,method,path,params=None,payload=None):
    t=token(c)
    url=API[c['environment']]+'/v3/company/'+t['realm_id']+'/'+path
    p={'minorversion':'75',**(params or {})}
    resp=requests.request(method,url,params=p,json=payload,headers={'Authorization':'Bearer '+t['access_token'],'Accept':'application/json','Content-Type':'application/json'},timeout=45)
    if not resp.ok:raise RuntimeError('QuickBooks '+str(resp.status_code)+': '+resp.text[:1100])
    return resp.json()

def query(c,sql):
    out=[];start=1
    while True:
        clause=sql+f' STARTPOSITION {start} MAXRESULTS 1000'
        data=api(c,'GET','query',{'query':clause})['QueryResponse']
        typ=sql.split('FROM ',1)[1].split()[0]
        rows=data.get(typ,[])
        out.extend(rows)
        if len(rows)<1000:break
        start+=1000
    return out

def resolve_accounts(c):
    a=query(c,"SELECT * FROM Account WHERE Active = true")
    def find(label):
        matches=[x for x in a if x.get('Name')==label or x.get('FullyQualifiedName')==label or (x.get('AcctNum','')+' '+x.get('Name','')).strip()==label]
        if len(matches)!=1:raise ValueError('Account must resolve uniquely: '+label+'; candidates: '+str([(x.get('Id'),x.get('Name'),x.get('AcctNum')) for x in a if label.split()[-1].casefold() in x.get('Name','').casefold()][:10]))
        return matches[0]
    bank=find('Payroll (CEN 2701)');clearing=find('1050 Clearing Accrued Payroll')
    if bank.get('AccountType')!='Bank':raise ValueError('Payroll (CEN 2701) must be a Bank account')
    return bank,clearing

def resolve_payees(c,rows):
    options=[]
    for typ in ('Employee','Vendor'):
        options.extend([(typ,x) for x in query(c,'SELECT * FROM '+typ+' WHERE Active = true')])
    byname={}
    for typ,x in options:
        n=qnorm(x.get('DisplayName') or x.get('Name') or x.get('FullyQualifiedName'))
        byname.setdefault(n,[]).append((typ,x))
    out={};issues=[]
    for name in sorted({x['name'] for x in rows}):
        m=byname.get(qnorm(name),[])
        if len(m)==1:out[name]=m[0]
        else:issues.append((name,'NOT FOUND' if not m else 'AMBIGUOUS',[(t,x.get('Id'),x.get('DisplayName')) for t,x in m]))
    return out,issues

def previous_log():
    out=set()
    if LOG.exists():
        for l in LOG.read_text().splitlines():
            try:
                x=json.loads(l)
                if x.get('status')=='posted':out.add(x['key'])
            except ValueError:pass
    return out

def inspect(c,rows):
    bank,clearing=resolve_accounts(c);payees,issues=resolve_payees(c,rows)
    start=min(r['date'] for r in rows);end=max(r['date'] for r in rows)
    purchases=query(c,f"SELECT * FROM Purchase WHERE TxnDate >= '{start}' AND TxnDate <= '{end}'")
    remote_numbers={}
    remote_keys=set()
    for p in purchases:
        n=str(p.get('CheckPayment',{}).get('CheckNum','') or p.get('DocNumber','')).strip()
        if p.get('PaymentType')=='Check' and n:remote_numbers.setdefault(n,[]).append(p)
        note=p.get('PrivateNote','')
        for r in rows:
            if r['key'] in note:remote_keys.add(r['key'])
    logged=previous_log();ready=[];blocked=[]
    for r in rows:
        reasons=[]
        if r['name'] not in payees:reasons.append('unmatched/ambiguous payee')
        if r['key'] in logged:reasons.append('already posted in local log')
        if r['key'] in remote_keys:reasons.append('already posted in QuickBooks memo')
        if r['number'] in remote_numbers:reasons.append('existing QuickBooks check number in date window')
        if reasons:blocked.append((r,', '.join(reasons)))
        else:ready.append(r)
    return bank,clearing,payees,ready,blocked,issues

def report(c,filename,post=False,confirm=None,limit=None):
    rows=records(filename)
    bank,clearing,payees,ready,blocked,issues=inspect(c,rows)
    print('\nQBO company:',token(c)['realm_id'],'environment:',c['environment'])
    print('Bank:',bank['Name'],'('+bank['Id']+') / split:',clearing['Name'],'('+clearing['Id']+')')
    print('Source:',len(rows),'checks, $'+str(sum((x['amount'] for x in rows),D('0'))))
    print('Ready:',len(ready),'$'+str(sum((x['amount'] for x in ready),D('0'))),'Blocked:',len(blocked))
    print('Preview (first 15):')
    for r in ready[:15]:print(r['date'],r['number'],r['name'],str(r['amount']))
    if blocked:
        print('\nBlocked checks (first 25):')
        for r,reason in blocked[:25]:print(r['number'],r['name'],reason)
    if issues:
        print('\nPayee mapping problems (first 25):')
        for x in issues[:25]:print(x)
    if not post:return
    if blocked:sys.exit('Posting stopped: resolve ALL blocked checks first (or remove previously posted rows from source).')
    if not ready:sys.exit('No checks to post.')
    if c['environment']=='production' and not c.get('production_enabled',False):sys.exit('Set production_enabled=true in config.json only AFTER successful sandbox test.')
    total=sum((r['amount'] for r in ready),D('0'))
    expected=f'POST {len(ready)} {total:.2f}'
    if confirm!=expected:sys.exit('No posting. Rerun with --confirm "'+expected+'"')
    if limit:ready=ready[:limit]
    for i,r in enumerate(ready,1):
        typ,payee=payees[r['name']]
        payload={'AccountRef':{'value':bank['Id']},'PaymentType':'Check','EntityRef':{'value':payee['Id'],'type':typ},'TxnDate':r['date'], 'TotalAmt':float(r['amount']), 'CheckPayment':{'CheckNum':r['number']},'PrivateNote':r['key']+' | Paychex payroll', 'Line':[{'Amount':float(r['amount']),'DetailType':'AccountBasedExpenseLineDetail','AccountBasedExpenseLineDetail':{'AccountRef':{'value':clearing['Id']}}}]}
        # Check duplicate again immediately before creating each check.
        if any(str(p.get('CheckPayment',{}).get('CheckNum',''))==r['number'] for p in query(c,f"SELECT * FROM Purchase WHERE TxnDate = '{r['date']}'")):
            print('STOP: QuickBooks check already exists:',r['number']);break
        try:
            data=api(c,'POST','purchase',payload=payload)
            created=data.get('Purchase',{})
            with LOG.open('a',encoding='utf8') as log:log.write(json.dumps({'status':'posted','key':r['key'],'qbo_id':created.get('Id'),'date':r['date'],'amount':str(r['amount'])})+'\n')
            print('POSTED',i,'/',len(ready),r['number'],'QBO ID:',created.get('Id'))
        except Exception as ex:
            print('STOP: QBO response unknown; check QuickBooks before retrying:',r['number'],ex);break

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='command',required=True)
    sub.add_parser('connect')
    for cmd in ('preview','post'):
        q=sub.add_parser(cmd);q.add_argument('file');
        if cmd=='post':q.add_argument('--confirm',required=True);q.add_argument('--limit',type=int,help='post first N checks for controlled test')
    args=p.parse_args();c=cfg()
    if args.command=='connect':connect(c)
    else:report(c,args.file,args.command=='post',getattr(args,'confirm',None),getattr(args,'limit',None))
