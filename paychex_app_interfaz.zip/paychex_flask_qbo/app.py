"""Local-only QuickBooks Online sandbox payroll check importer.
No production posting path is exposed in this app.
"""
import base64
import datetime as dt
import hashlib
import io
import json
import os
import re
import secrets
import sqlite3
import time
from collections import Counter
from decimal import Decimal
from pathlib import Path
from urllib.parse import urlencode

import requests
from cryptography.fernet import Fernet, InvalidToken
from dotenv import load_dotenv
from flask import Flask, flash, redirect, render_template, request, session, url_for

from paychex_parser_legacy import records, qnorm

ROOT = Path(__file__).resolve().parent
load_dotenv(ROOT / '.env')
AUTH_URL = 'https://appcenter.intuit.com/connect/oauth2'
TOKEN_URL = 'https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer'
BASE = 'https://sandbox-quickbooks.api.intuit.com'
SCOPES = 'com.intuit.quickbooks.accounting'  # payments and PII scopes not required for checks
BANK_NAME = 'Payroll (CEN 2701)'
CLEARING_NUMBER = '1050'
CLEARING_NAME = 'Clearing Accrued Payroll'
DB = ROOT / 'local_state.db'

required = ('INTUIT_CLIENT_ID', 'INTUIT_CLIENT_SECRET', 'INTUIT_REDIRECT_URI',
            'FLASK_SECRET_KEY', 'TOKEN_ENCRYPTION_KEY')
missing = [k for k in required if not os.getenv(k) or os.environ[k].startswith(('YOUR_', 'PASTE_'))]
if missing:
    raise RuntimeError('Set these values in your local .env file: ' + ', '.join(missing))
if os.getenv('QBO_ENV', 'sandbox') != 'sandbox':
    raise RuntimeError('Only sandbox mode is supported in this project.')
REDIRECT = os.environ['INTUIT_REDIRECT_URI']
if REDIRECT != 'http://localhost:8765/oauth/callback':
    raise RuntimeError('Register http://localhost:8765/oauth/callback exactly in Intuit Developer.')
fernet = Fernet(os.environ['TOKEN_ENCRYPTION_KEY'].encode())
app = Flask(__name__)
app.secret_key = os.environ['FLASK_SECRET_KEY']
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax',
                  SESSION_COOKIE_SECURE=False, MAX_CONTENT_LENGTH=6 * 1024 * 1024)


def database():
    conn = sqlite3.connect(DB, timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA journal_mode=WAL')
    conn.execute('''CREATE TABLE IF NOT EXISTS auth (
      id INTEGER PRIMARY KEY CHECK(id=1), realm TEXT NOT NULL,
      encrypted BLOB NOT NULL, updated REAL NOT NULL)''')
    conn.execute('''CREATE TABLE IF NOT EXISTS review (
      id TEXT PRIMARY KEY, realm TEXT NOT NULL, payload TEXT NOT NULL,
      created REAL NOT NULL, confirmation TEXT NOT NULL)''')
    conn.execute('''CREATE TABLE IF NOT EXISTS posting (
      realm TEXT NOT NULL, payroll_date TEXT NOT NULL, check_no TEXT NOT NULL,
      status TEXT NOT NULL, qbo_id TEXT, note TEXT,
      updated REAL NOT NULL, PRIMARY KEY(realm, payroll_date,check_no))''')
    conn.commit()
    return conn


class QBOError(Exception):
    pass


def tokens():
    with database() as db:
        row = db.execute('SELECT * FROM auth WHERE id=1').fetchone()
    if not row:
        raise QBOError('Connect a QuickBooks sandbox company first.')
    try:
        return row['realm'], json.loads(fernet.decrypt(row['encrypted']).decode())
    except (InvalidToken, ValueError) as e:
        raise QBOError('Could not decrypt tokens. Check TOKEN_ENCRYPTION_KEY.') from e


def save_tokens(realm, body, invalidate_review=True):
    with database() as db:
        db.execute('REPLACE INTO auth(id,realm,encrypted,updated) VALUES(1,?,?,?)',
                   (realm, fernet.encrypt(json.dumps(body).encode()), time.time()))
        if invalidate_review:
            db.execute('DELETE FROM review')
        db.commit()


def exchange(form):
    basic = base64.b64encode((os.environ['INTUIT_CLIENT_ID'] + ':' +
                             os.environ['INTUIT_CLIENT_SECRET']).encode()).decode()
    try:
        r = requests.post(TOKEN_URL, data=form,
                          headers={'Authorization': 'Basic ' + basic,
                                   'Accept': 'application/json',
                                   'Content-Type': 'application/x-www-form-urlencoded'}, timeout=25)
        r.raise_for_status()
        return r.json()
    except requests.RequestException as e:
        raise QBOError('OAuth token request failed; verify Intuit settings and reconnect.') from e


def bearer():
    realm, t = tokens()
    if time.time() > float(t.get('obtained', 0)) + int(t.get('expires_in', 3600)) - 120:
        updated = exchange({'grant_type': 'refresh_token', 'refresh_token': t['refresh_token']})
        updated['obtained'] = time.time()
        # Intuit rotates refresh tokens; always persist the new refresh token.
        t.update(updated)
        save_tokens(realm, t, invalidate_review=False)
    return realm, t['access_token']


def api(method, path, *, params=None, payload=None):
    realm, access = bearer()
    url = f'{BASE}/v3/company/{realm}/{path}'
    try:
        r = requests.request(method, url, params=params, json=payload,
                             headers={'Authorization': 'Bearer ' + access,
                                      'Accept': 'application/json',
                                      'Content-Type': 'application/json'}, timeout=35)
    except requests.Timeout as e:
        raise QBOError('Request timed out. Check QuickBooks before retrying any POST.') from e
    except requests.RequestException as e:
        raise QBOError('QuickBooks network error. Verify connection.') from e
    if not r.ok:
        # Avoid printing response bodies that may contain sensitive person info.
        raise QBOError(f'QuickBooks HTTP {r.status_code}. Verify app scopes/account mapping. Request not confirmed.')
    try:
        return r.json()
    except ValueError as e:
        raise QBOError('QuickBooks returned invalid JSON.') from e


def query_all(entity, where=''):
    if entity not in ('Employee', 'Account', 'Purchase'):
        raise ValueError('Unsupported QuickBooks entity')
    results = []
    start = 1
    while True:
        sql = f'SELECT * FROM {entity} {where} STARTPOSITION {start} MAXRESULTS 1000'
        data = api('GET', 'query', params={'query': sql})
        page = data.get('QueryResponse', {}).get(entity, [])
        results.extend(page)
        if len(page) < 1000:
            return results
        start += len(page)
        if start > 100000:
            raise QBOError('Query exceeded safety pagination limit.')


def account_mapping():
    accounts = query_all('Account')
    banks = [a for a in accounts if a.get('Active', True) and
             (a.get('Name') == BANK_NAME or a.get('FullyQualifiedName') == BANK_NAME)
             and a.get('AccountType') == 'Bank']
    clears = [a for a in accounts if a.get('Active', True) and
              a.get('AcctNum') == CLEARING_NUMBER and
              (a.get('Name') == CLEARING_NAME or a.get('FullyQualifiedName') == CLEARING_NAME)]
    if len(banks) != 1 or len(clears) != 1:
        raise QBOError(f'Accounts not matched exactly: bank={len(banks)}, clearing={len(clears)}. '
                       'Add matching accounts to your sandbox company (or inspect account names).')
    return banks[0], clears[0]


def remote_purchase_index(start, end, bank_id):
    purchases = query_all('Purchase', f"WHERE TxnDate >= '{start}' AND TxnDate <= '{end}'")
    remote = set()
    for p in purchases:
        if p.get('PaymentType') != 'Check' or p.get('AccountRef', {}).get('value') != str(bank_id):
            continue
        payee = p.get('EntityRef', {}).get('value')
        amt = str(Decimal(str(p.get('TotalAmt', 0))).quantize(Decimal('.01')))
        remote.add((p.get('TxnDate'), str(p.get('PaymentRefNum', '')).strip()))
    return remote


def review_file(stream, filename):
    if not filename.lower().endswith(('.xlsx', '.csv')):
        raise QBOError('Upload .xlsx or .csv only.')
    # Parser accepts file paths; temporary data is deleted immediately after parsing.
    import tempfile
    with tempfile.TemporaryDirectory() as temp:
        name = Path(temp) / ('payroll.xlsx' if filename.lower().endswith('.xlsx') else 'payroll.csv')
        name.write_bytes(stream.read())
        try:
            rows = records(str(name))
        except (ValueError, SystemExit, OSError, KeyError) as e:
            raise QBOError('Could not parse Paychex check report: ' + str(e)) from e
    if len(rows) > 3000:
        raise QBOError('Maximum 3000 checks per upload.')
    bank, clear = account_mapping()
    employees = query_all('Employee')
    by_name = {}
    for e in employees:
        if e.get('Active', True):
            by_name.setdefault(qnorm(e.get('DisplayName')), []).append(e)
    realm, _ = tokens()
    first, last = min(x['date'] for x in rows), max(x['date'] for x in rows)
    remote = remote_purchase_index(first, last, bank['Id'])
    with database() as db:
        local = {(r['payroll_date'], r['check_no']) for r in
                 db.execute('SELECT payroll_date,check_no FROM posting WHERE realm=?', (realm,))}
    preview = []
    for row in rows:
        candidates = by_name.get(qnorm(row['name']), [])
        reason = ''
        if len(candidates) != 1:
            reason = 'No exact active Employee match' if not candidates else 'Ambiguous employee name'
        emp_id = str(candidates[0]['Id']) if len(candidates) == 1 else ''
        money = str(row['amount'])
        remote_key = (row['date'], row['number'])
        if (row['date'], row['number']) in local:
            reason = 'Previously attempted locally (review posting log)'
        elif remote_key in remote:
            reason = 'Already exists in QuickBooks'
        preview.append({'number': row['number'], 'name': row['name'], 'date': row['date'],
                        'amount': money, 'employee_id': emp_id, 'reason': reason})
    # Block the entire review when any row isn't safe; immutable server-side snapshot.
    fingerprint = hashlib.sha256(json.dumps(preview, sort_keys=True).encode()).hexdigest()[:12]
    confirmation = 'POST ' + str(len(preview)) + ' ' + str(sum(Decimal(x['amount']) for x in preview)) + ' ' + fingerprint
    review_id = secrets.token_urlsafe(24)
    data = {'rows': preview, 'bank_id': str(bank['Id']), 'clearing_id': str(clear['Id']),
            'bank': bank['Name'], 'clearing': clear.get('AcctNum', '') + ' ' + clear['Name']}
    with database() as db:
        db.execute('DELETE FROM review')
        db.execute('INSERT INTO review VALUES(?,?,?,?,?)',
                   (review_id, realm, json.dumps(data), time.time(), confirmation))
        db.commit()
    return review_id, data, confirmation


def create_check(row, bank_id, clearing_id):
    payload = {'PaymentType': 'Check', 'AccountRef': {'value': bank_id},
               'EntityRef': {'value': row['employee_id'], 'type': 'Employee'},
               'TxnDate': row['date'], 'PaymentRefNum': row['number'],
               'PrivateNote': 'Paychex import ' + row['date'] + ' #' + row['number'],
               'Line': [{'Amount': float(Decimal(row['amount'])),
                         'DetailType': 'AccountBasedExpenseLineDetail',
                         'AccountBasedExpenseLineDetail': {'AccountRef': {'value': clearing_id}}}]}
    return api('POST', 'purchase', payload=payload)['Purchase']


@app.before_request
def local_guard():
    if request.remote_addr not in ('127.0.0.1', '::1'):
        return 'Local access only', 403
    if 'csrf' not in session:
        session['csrf'] = secrets.token_urlsafe(24)
    if request.method == 'POST' and not secrets.compare_digest(
            session['csrf'], request.form.get('csrf', '')):
        return 'Invalid CSRF token', 403


@app.route('/')
def index():
    try:
        realm, _ = tokens()
    except QBOError:
        realm = None
    return render_template('index.html', realm=realm)


@app.route('/connect')
def connect():
    state = secrets.token_urlsafe(32)
    session['oauth_state'] = state
    session['oauth_created'] = time.time()
    args = {'client_id': os.environ['INTUIT_CLIENT_ID'],
            'redirect_uri': REDIRECT, 'response_type': 'code',
            'scope': SCOPES, 'state': state}
    return redirect(AUTH_URL + '?' + urlencode(args))


@app.route('/oauth/callback')
def callback():
    if (not session.get('oauth_state') or time.time() - session.get('oauth_created', 0) > 600 or
            not secrets.compare_digest(request.args.get('state', ''), session.pop('oauth_state'))):
        return 'OAuth state invalid or expired', 400
    if 'error' in request.args:
        return 'Intuit authorization denied', 400
    code, realm = request.args.get('code'), request.args.get('realmId')
    if not code or not realm:
        return 'Missing code or realmId', 400
    try:
        t = exchange({'grant_type': 'authorization_code', 'code': code, 'redirect_uri': REDIRECT})
        t['obtained'] = time.time()
        save_tokens(realm, t)
    except QBOError as e:
        flash(str(e), 'error')
        return redirect(url_for('index'))
    flash('Connected sandbox company: ' + realm, 'ok')
    return redirect(url_for('index'))


@app.route('/preview', methods=['POST'])
def preview():
    file = request.files.get('payroll')
    if not file or not file.filename:
        flash('Select Paychex Excel or CSV.', 'error')
        return redirect(url_for('index'))
    try:
        review_id, data, confirmation = review_file(file.stream, file.filename)
    except QBOError as e:
        flash(str(e), 'error')
        return redirect(url_for('index'))
    session['review_id'] = review_id
    blocked = sum(bool(r['reason']) for r in data['rows'])
    return render_template('review.html', data=data, confirmation=confirmation,
                           blocked=blocked, total=sum(Decimal(x['amount']) for x in data['rows']))


@app.route('/review')
def review():
    review_id = session.get('review_id')
    with database() as db:
        item = db.execute('SELECT * FROM review WHERE id=?', (review_id,)).fetchone()
    if not item or time.time() - item['created'] > 1800:
        flash('No active preview or preview expired.', 'error')
        return redirect(url_for('index'))
    data = json.loads(item['payload'])
    blocked = sum(bool(r['reason']) for r in data['rows'])
    return render_template('review.html', data=data, confirmation=item['confirmation'],
                           blocked=blocked, total=sum(Decimal(x['amount']) for x in data['rows']))


@app.route('/post', methods=['POST'])
def post():
    review_id = session.get('review_id')
    with database() as db:
        item = db.execute('SELECT * FROM review WHERE id=?', (review_id,)).fetchone()
    if not item or time.time() - item['created'] > 1800:
        flash('Preview expired. Upload again.', 'error')
        return redirect(url_for('index'))
    if request.form.get('confirmation') != item['confirmation']:
        flash('Confirmation does not match. Nothing posted.', 'error')
        return redirect(url_for('review'))
    data = json.loads(item['payload'])
    if any(x['reason'] for x in data['rows']):
        flash('Blocked preview: fix all rows before posting.', 'error')
        return redirect(url_for('review'))
    realm, _ = tokens()
    if item['realm'] != realm:
        flash('Connected company changed. Upload again.', 'error')
        return redirect(url_for('index'))
    # Reverify remote state immediately before posting to avoid stale preview.
    try:
        bank, clear = account_mapping()
        if str(bank['Id']) != data['bank_id'] or str(clear['Id']) != data['clearing_id']:
            raise QBOError('QuickBooks account mapping changed.')
        dates = [r['date'] for r in data['rows']]
        remote = remote_purchase_index(min(dates), max(dates), data['bank_id'])
        if any((r['date'], r['number']) in remote for r in data['rows']):
            raise QBOError('A duplicate appeared in QuickBooks since preview. Upload again.')
    except QBOError as e:
        flash(str(e), 'error')
        return redirect(url_for('review'))
    completed = 0
    failure = None
    for r in data['rows']:
        # Atomic reservation: blocked also on errors/uncertain API outcomes.
        with database() as db:
            try:
                db.execute('INSERT INTO posting VALUES(?,?,?,?,?,?,?)',
                           (realm, r['date'], r['number'], 'attempted', None,
                            'Reserved before API POST', time.time()))
                db.commit()
            except sqlite3.IntegrityError:
                failure = 'Previously attempted check detected; stopped.'
                break
        try:
            created = create_check(r, data['bank_id'], data['clearing_id'])
            with database() as db:
                db.execute('UPDATE posting SET status=?,qbo_id=?,note=?,updated=? '
                           'WHERE realm=? AND payroll_date=? AND check_no=?',
                           ('posted', str(created['Id']), 'Created sandbox Purchase Check',
                            time.time(), realm, r['date'], r['number']))
                db.commit()
            completed += 1
        except (QBOError, KeyError, ValueError) as e:
            failure = 'Posting stopped at check ' + r['number'] + ': ' + str(e)
            break
    with database() as db:
        db.execute('DELETE FROM review WHERE id=?', (review_id,))
        db.commit()
    session.pop('review_id', None)
    flash(f'Posted {completed} sandbox check(s). ' +
          (failure or 'All checks created. Verify bank register.'),
          'error' if failure else 'ok')
    return redirect(url_for('index'))


@app.errorhandler(413)
def too_large(_):
    return 'File exceeds 6 MB upload limit', 413


if __name__ == '__main__':
    database().close()
    app.run(host='127.0.0.1', port=8765, debug=False, use_reloader=False)
