# Paychex → QuickBooks Online — Flask v2

## Installation (Windows)

1. Extract the ZIP to a **new directory**, do not overwrite the tested v1 folder.
2. `py -m pip install -r requirements.txt`
3. `Copy-Item .env.example .env` and `py generate_keys.py`; paste generated keys into `.env`.
4. Add Intuit Development credentials and register the exact redirect `http://localhost:8765/oauth/callback` in Intuit Developer Development.
5. `py app.py` and open `http://localhost:8765`.
6. Authorize **Sandbox**, upload a sample Paychex report, preview, and confirm an explicitly reviewed test POST.

**Do not copy private credentials, `.env`, or `local_state.db` into a ZIP or chat. Rotate exposed credentials.**

## What changed

- Independently checks existing **QBO Purchase Check** records for the connected bank in an expanded date range, including checks previously imported by Xenett. Conservatively blocks a collision by check number, or by payee + date + amount (also handles checks without a number).
- Checks QBO again just before POST and reserves check numbers in SQLite before posting; uncertain network attempts require manual reconciliation.
- Records check history and assigned QBO IDs in the **Import history** page.
- Identifies clearing account by exact name with optional number, rather than assuming AcctNum is always returned. Does not hard-code sandbox account IDs.
- Supports isolated Production OAuth **PREVIEW ONLY**, with separate `production_state.db`; production posting defaults disabled. App still binds to localhost.

## Production requirements — read before changing QBO_ENV

- Intuit Developer Production keys/permissions and a registered **HTTPS callback URL** are required. The local HTTP sandbox callback is not a production callback. Production authorization routing/deployment must be configured securely; this ZIP does not automatically provide an HTTPS receiver, public hosting, or tunnel. Do not expose Flask's development server publicly.
- Change to `QBO_ENV=production`, supply separate production keys and registered HTTPS callback, and keep `ALLOW_PRODUCTION_POST=false` until you finish production read-only previews and accounting verification. The system stores production tokens/history separately. The OAuth callback requires a separately configured secure ingress solution for production.
- Production posting is a controlled opt-in only: set `ALLOW_PRODUCTION_POST=true` **after** validating source data, employee mappings, account mappings, duplicate detection and prior Xenett postings. The UI requires typed batch confirmation and production Realm ID. This is not a guarantee against duplicate accounting; independently reconcile the register. Preserve complete backups.
- Due to the single-user local design, operate only on a trusted machine, never expose Flask directly to the internet or LAN. Production use also calls for periodic backups and access controls.
- Check reconciliation matches in QBO bank feeds are suggested, not guaranteed, and existing Paychex journal entries must not already credit the same bank account for net wages.

## Official documentation

- https://developer.intuit.com/app/developer/qbo/docs/develop/authentication-and-authorization/oauth-2.0
- https://developer.intuit.com/app/developer/qbo/docs/api/accounting/all-entities/purchase
- https://developer.intuit.com/app/developer/qbo/docs/api/accounting/all-entities/account
- https://developer.intuit.com/app/developer/qbo/docs/api/accounting/all-entities/employee
